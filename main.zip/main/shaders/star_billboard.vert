#version 330

in vec3 in_position;
in float in_brightness;
in float in_size;
in vec3 in_color;
in float in_glow_strength;

out float vertex_brightness;
out float vertex_size;
out vec3 vertex_color;
out float vertex_glow_strength;

void main()
{
    gl_Position = vec4(in_position, 1.0);
    vertex_brightness = in_brightness;
    vertex_size = in_size;
    vertex_color = in_color;
    vertex_glow_strength = in_glow_strength;
}
