#version 330

in vec2 sprite_uv;
in float sprite_brightness;
in vec3 sprite_color;
in float sprite_fade;
in float sprite_glow_strength;
in float sprite_radius_pixels;
out vec4 fragment_color;

void main()
{
    float radius_squared = dot(sprite_uv, sprite_uv);

    if (radius_squared > 1.0) {
        discard;
    }

    float point_core = exp(-radius_squared * 42.0);
    float bright_core = exp(-radius_squared * 16.0) * sprite_glow_strength;
    float subtle_glow = exp(-radius_squared * 4.5) * sprite_glow_strength * 0.22;
    float subpixel_alpha = smoothstep(0.12, 0.75, sprite_radius_pixels);
    float intensity =
        (point_core + bright_core * 0.5 + subtle_glow)
        * sprite_brightness
        * sprite_fade
        * subpixel_alpha;

    vec3 color = sprite_color * intensity * 1.35;
    fragment_color = vec4(color, clamp(intensity, 0.0, 0.85));
}
