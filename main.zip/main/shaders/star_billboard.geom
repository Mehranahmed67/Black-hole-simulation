#version 330

layout(points) in;
layout(triangle_strip, max_vertices = 4) out;

uniform mat4 view_matrix;
uniform mat4 projection_matrix;
uniform vec3 camera_position;
uniform vec3 camera_right;
uniform vec3 camera_up;
uniform float viewport_height;
uniform float fade_start;
uniform float fade_end;

in float vertex_brightness[];
in float vertex_size[];
in vec3 vertex_color[];
in float vertex_glow_strength[];

out vec2 sprite_uv;
out float sprite_brightness;
out vec3 sprite_color;
out float sprite_fade;
out float sprite_glow_strength;
out float sprite_radius_pixels;

void emit_corner(vec3 center, vec2 corner, float fade, float half_world_size, float radius_pixels)
{
    vec3 offset =
        camera_right * corner.x * half_world_size
        + camera_up * corner.y * half_world_size;

    gl_Position = projection_matrix * view_matrix * vec4(center + offset, 1.0);
    sprite_uv = corner;
    sprite_brightness = vertex_brightness[0];
    sprite_color = vertex_color[0];
    sprite_fade = fade;
    sprite_glow_strength = vertex_glow_strength[0];
    sprite_radius_pixels = radius_pixels;
    EmitVertex();
}

void main()
{
    vec3 center = gl_in[0].gl_Position.xyz;
    float distance_to_camera = length(center - camera_position);
    float far_fade = 1.0 - smoothstep(fade_start, fade_end, distance_to_camera);
    float near_fade = smoothstep(0.75, 2.5, distance_to_camera);
    float fade = far_fade * near_fade;

    if (fade <= 0.001) {
        return;
    }

    float projection_scale = projection_matrix[1][1];
    float safe_distance = max(distance_to_camera, 0.001);
    float projected_radius_pixels =
        vertex_size[0] * projection_scale * viewport_height / safe_distance;

    float max_radius_pixels = mix(1.15, 3.25, vertex_glow_strength[0]);
    float radius_pixels = min(projected_radius_pixels, max_radius_pixels);

    if (radius_pixels < 0.12) {
        return;
    }

    float half_view_height_world = safe_distance / projection_scale;
    float world_units_per_pixel = (2.0 * half_view_height_world) / viewport_height;
    float half_world_size = radius_pixels * world_units_per_pixel;

    emit_corner(center, vec2(-1.0, -1.0), fade, half_world_size, radius_pixels);
    emit_corner(center, vec2( 1.0, -1.0), fade, half_world_size, radius_pixels);
    emit_corner(center, vec2(-1.0,  1.0), fade, half_world_size, radius_pixels);
    emit_corner(center, vec2( 1.0,  1.0), fade, half_world_size, radius_pixels);
    EndPrimitive();
}
