# Configuration class umm can say it as the settings of the simulation

class Config:
    """Single place for engine and scene tuning values."""

    window_name = "Black Hole simulation"
    size_of_window = (1280, 720)
    window_color = (0.0, 0.0, 0.0, 1.0)

    cam_position = (0.0, 2.5, 6.0)
    cam_pitch = -22.0
    cam_yaw = -90.0
    cam_speed = 3.5
    cam_sensi = 0.12
    cam_fov = 60.0
    cam_near_plane = 0.1
    cam_far_plane = 1000.0
    cam_min_pitch = -89.0
    cam_max_pitch = 89.0

    size_of_world = (20.0, 20.0, 20.0)
    min_bounds = (-10.0, -5.0, -10.0)
    max_bounds = (10.0, 10.0, 10.0)
    grid_visible = True
    grid_size = 1.0
    max_grid_lines = 220
    grid_color = (0.22, 0.22, 0.22, 1.0)
    bounds_color = (0.38, 0.38, 0.38, 1.0)

    x_axis_color = (1.0, 0.16, 0.16, 1.0)
    z_axis_color = (1.0, 0.16, 0.16, 1.0)

    star_count = 5000
    star_randomness = 42
    min_star_brightness = 0.08
    max_star_brightness = 0.9
    min_star_size = 0.004
    max_star_size = 0.055

    galaxy_image = "eso0932a_sky.jpg"
    galaxy_intensity = 1.0
    space_star_count = 26000
    space_star_randomness = 959
    space_background_intensity = 0.82
    milkyway_intensity = 0.205
    milkyway_width = 0.22
    milkyway_dust_opacity = 0.68
    milkyway_irregularity = 0.075
    nebula_intensity = 0.78
    spacehaze_intensity = 0.045
    lens_power = 1.35
    lens_radius = 7.0
    lens_softening = 0.55
    lens_ring_brightness = 0.42

    bh_position = (0.0, 0.0, 0.0)
    bh_rotation = (0.0, 0.0, 0.0)
    bh_gravitional_constant = 1.0
    bh_light_speed = 1.0
    bh_mass = 0.375
    bh_latitude_part = 32
    bh_longitude_part = 64
    bh_radius = 0.75
    bh_min_radius = 0.35
    bh_max_radius = 6.0
    bh_slider_step = 0.08
    bh_color = (0.0, 0.0, 0.0, 1.0)

    acc_disk_inn_rad = 1.05
    acc_disk_out_rad = 3.2
    acc_disk_min_out_rad = 1.8
    acc_disk_max_out_rad = 5.6
    acc_disk_slider_step = 0.06
    acc_disk_thickness = 0.08
    acc_disk_min_scale = 0
    acc_disk_default_scale = 1.0
    acc_disk_max_scale = 1.8
    acc_disk_particles = 50000
    acc_disk_randomness = 500

    debug_font = "Consolas"
    debug_font_size = 12
    debug_position = (12, 12)
    debug_width = 420
    debug_color = (225, 225, 225, 255)
    debug_selected_colour = (255, 238, 180, 255)
    debug_panel_padding = 18
    debug_panel_width = 280
    debug_panel_height = 118
    debug_panel_inset = 20
    debug_slider_vert_gap = 48
    debug_slider_width = 220
    debug_slider_key_repeat_rate = 0.9
    bh_slider_key = ("B",)
    acc_disk_key = ("N",)
    slider_decr_key = ("Z",)
    slider_inc_key = ("X",)


# this class, one can say it provides common properties which other classes inherit or it is the base class

class BaseObject:

    def __init__(
        self,
        position=(0.0, 0.0, 0.0),
        rotation=(0.0, 0.0, 0.0),
        scale=(1.0, 1.0, 1.0),
    ):
        self.position = position
        self.rotation = rotation
        self.scale = scale

    def update(self, delta_time):
        """Update this object."""

    def render(self, render_manager):
        render_manager.submit(self)



import glm

#this class basically draws simple colored geometry

class ColoredShapeShader:

    def __init__(self, context):
        self.program = context.program(
            vertex_shader="""
                #version 330

                // Vertices are now true 3D world/model-space positions.
                in vec3 in_position;
                in vec4 in_color;

                // The model matrix places an object into world space.
                // The view matrix moves world space into camera space.
                // The projection matrix applies perspective.
                uniform mat4 model_matrix;
                uniform mat4 view_matrix;
                uniform mat4 projection_matrix;

                out vec4 vertex_color;

                void main()
                {
                    gl_Position =
                        projection_matrix
                        * view_matrix
                        * model_matrix
                        * vec4(in_position, 1.0);
                    vertex_color = in_color;
                }
            """,
            fragment_shader="""
                #version 330

                // Unlit flat color. Lighting is intentionally not implemented
                // yet, so every fragment uses the interpolated vertex color.
                in vec4 vertex_color;
                out vec4 fragment_color;

                void main()
                {
                    fragment_color = vertex_color;
                }
            """,
        )

    def apply_transform(self, base_object):
        """Send one object's model matrix to the GPU."""
        model_matrix = glm.mat4(1.0)
        model_matrix = glm.translate(model_matrix, glm.vec3(*base_object.position))
        model_matrix = glm.rotate(
            model_matrix,
            base_object.rotation[0],
            glm.vec3(1.0, 0.0, 0.0),
        )
        model_matrix = glm.rotate(
            model_matrix,
            base_object.rotation[1],
            glm.vec3(0.0, 1.0, 0.0),
        )
        model_matrix = glm.rotate(
            model_matrix,
            base_object.rotation[2],
            glm.vec3(0.0, 0.0, 1.0),
        )
        model_matrix = glm.scale(model_matrix, glm.vec3(*base_object.scale))
        self.program["model_matrix"].write(model_matrix.to_bytes())

    def apply_camera(self, camera, viewport_aspect):
        """Send view and projection matrices to the GPU before drawing."""
        view_matrix = camera.get_view_matrix()
        projection_matrix = camera.get_projection_matrix(viewport_aspect)

        self.program["view_matrix"].write(view_matrix.to_bytes())
        self.program["projection_matrix"].write(projection_matrix.to_bytes())
        self.program["model_matrix"].write(glm.mat4(1.0).to_bytes())

import glm

# class which deals with camera

class Camera:

    def __init__(self, config=Config):
        self.def_position = glm.vec3(*config.cam_position)
        self.def_pitch = config.cam_pitch
        self.def_yaw = config.cam_yaw

        self.position = glm.vec3(self.def_position)
        self.pitch = self.def_pitch
        self.yaw = self.def_yaw
        self.fov = config.cam_fov
        self.near_plane = config.cam_near_plane
        self.far_plane = config.cam_far_plane

        self.speed = config.cam_speed
        self.def_speed = config.cam_speed
        self.sensitivity = config.cam_sensi
        self.min_pitch = config.cam_min_pitch
        self.max_pitch = config.cam_max_pitch
        self.min_speed = 0.25
        self.max_speed = 50.0
        self.speed_step = 0.85
        self.fast_speed_multiplier = 3.0
        self.slow_speed_multiplier = 0.25
        self.acceleration = 16.0
        self.deceleration = 12.0

        self.world_up = glm.vec3(0.0, 1.0, 0.0)
        self.forward = glm.vec3(0.0, 0.0, -1.0)
        self.right = glm.vec3(1.0, 0.0, 0.0)
        self.up = glm.vec3(0.0, 1.0, 0.0)
        self.velocity = glm.vec3(0.0)
        self.movement_input = glm.vec3(0.0)
        self.speed_multiplier = 1.0
        self._update_direction_vectors()

    @property
    def position_x(self):
        return self.position.x

    @property
    def position_y(self):
        return self.position.y

    @property
    def position_z(self):
        return self.position.z

    @property
    def position_3d(self):
        return self.position.x, self.position.y, self.position.z

    def rotate(self, mouse_delta_x, mouse_delta_y):
        self.yaw += mouse_delta_x * self.sensitivity
        self.pitch -= mouse_delta_y * self.sensitivity
        self.pitch = max(self.min_pitch, min(self.max_pitch, self.pitch))
        self._update_direction_vectors()

    def set_movement_input(self, forward, right, vertical, fast=False, slow=False):
        self.movement_input = glm.vec3(right, vertical, forward)
        self.speed_multiplier = 1.0

        if fast:
            self.speed_multiplier *= self.fast_speed_multiplier
        if slow:
            self.speed_multiplier *= self.slow_speed_multiplier

    def adjust_move_speed(self, scroll_delta):
        if scroll_delta == 0:
            return

        self.speed += scroll_delta * self.speed_step
        self.speed = max(
            self.min_speed,
            min(self.max_speed, self.speed),
        )

    def reset(self):
        self.position = glm.vec3(self.def_position)
        self.pitch = self.def_pitch
        self.yaw = self.def_yaw
        self.speed = self.def_speed
        self.velocity = glm.vec3(0.0)
        self.movement_input = glm.vec3(0.0)
        self.speed_multiplier = 1.0
        self._update_direction_vectors()

    def clamp_to_bounds(self, world):
        min_x, min_y, min_z = world.bounds_min
        max_x, max_y, max_z = world.bounds_max
        self.position.x = max(min_x, min(max_x, self.position.x))
        self.position.y = max(min_y, min(max_y, self.position.y))
        self.position.z = max(min_z, min(max_z, self.position.z))

    def get_view_matrix(self):
        return glm.lookAt(self.position, self.position + self.forward, self.up)

    def get_projection_matrix(self, aspect_ratio):
        return glm.perspective(
            glm.radians(self.fov),
            aspect_ratio,
            self.near_plane,
            self.far_plane,
        )

    def update(self, delta_time):
        if delta_time <= 0.0:
            return

        target_velocity = self._get_target_velocity()
        smoothing = self.acceleration if glm.length(target_velocity) else self.deceleration
        blend = min(1.0, smoothing * delta_time)

        self.velocity += (target_velocity - self.velocity) * blend
        self.position += self.velocity * delta_time

        if glm.length(self.velocity) < 0.001 and not glm.length(target_velocity):
            self.velocity = glm.vec3(0.0)

    def _get_target_velocity(self):
        if not glm.length(self.movement_input):
            return glm.vec3(0.0)

        direction = (
            self.forward * self.movement_input.z
            + self.right * self.movement_input.x
            + self.world_up * self.movement_input.y
        )

        if not glm.length(direction):
            return glm.vec3(0.0)

        return glm.normalize(direction) * self.speed * self.speed_multiplier

    def _update_direction_vectors(self):
        yaw_radians = glm.radians(self.yaw)
        pitch_radians = glm.radians(self.pitch)

        # Spherical coordinates turn yaw/pitch angles into a unit direction.
        forward = glm.vec3(
            glm.cos(yaw_radians) * glm.cos(pitch_radians),
            glm.sin(pitch_radians),
            glm.sin(yaw_radians) * glm.cos(pitch_radians),
        )
        self.forward = glm.normalize(forward)
        self.right = glm.normalize(glm.cross(self.forward, self.world_up))
        self.up = glm.normalize(glm.cross(self.right, self.forward))

# this class manages stars

class Star(BaseObject):

    def __init__(self, position, brightness, size, color, glow_strength):
        super().__init__(position=(position[0], position[1], position[2]))
        self.brightness = brightness
        self.size = size
        self.color = color
        self.glow_strength = glow_strength


from array import array
from math import cos, pi, sin

import moderngl

# this class creates the spherical geometry of the black hole

class BlackHole(BaseObject):

    def __init__(
        self,
        context,
        shader,
        position=Config.bh_position,
        mass=Config.bh_mass,
        rotation=Config.bh_rotation,
        radius=Config.bh_radius,
        event_horizon_radius=None,
        config=Config,
    ):
        super().__init__(position=position, rotation=rotation)
        self.context = context
        self.shader = shader
        self.mass = mass
        self.radius = radius
        self.base_radius = radius
        self.schwarzschild_radius = self._calculate_schwarzschild_radius(config)
        self.event_horizon_radius = (
            self.schwarzschild_radius
            if event_horizon_radius is None
            else event_horizon_radius
        )
        self.latitude_part = config.bh_latitude_part
        self.longitude_part = config.bh_longitude_part
        self.colour = config.bh_color

        self.vertex_buffer = self._create_sphere_vertex_buffer()
        self.vertex_count = self._calculate_vertex_count()
        self.vertex_array = self._create_vertex_array(self.vertex_buffer)

    def set_radius(self, radius):
        self.radius = radius
        self.event_horizon_radius = radius
        scale = radius / max(self.base_radius, 0.000001)
        self.scale = (scale, scale, scale)

    def _calculate_schwarzschild_radius(self, config):
        return (
            2.0
            * config.bh_gravitional_constant 
            * self.mass
            / (config.bh_light_speed ** 2.0)
        )

    def _sphere_point(self, latitude_angle, longitude_angle):
        x_position = self.radius * sin(latitude_angle) * cos(longitude_angle)
        y_position = self.radius * cos(latitude_angle)
        z_position = self.radius * sin(latitude_angle) * sin(longitude_angle)

        return x_position, y_position, z_position

    def _add_vertex(self, vertex_data, latitude_angle, longitude_angle):
        vertex_data.extend(
            [
                *self._sphere_point(latitude_angle, longitude_angle),
                *self.colour,
            ]
        )

    def _create_sphere_vertex_buffer(self):
        vertex_data = []

        for latitude_index in range(self.latitude_part):
            latitude_0 = pi * latitude_index / self.latitude_part
            latitude_1 = pi * (latitude_index + 1) / self.latitude_part

            for longitude_index in range(self.longitude_part):
                longitude_0 = 2.0 * pi * longitude_index / self.longitude_part
                longitude_1 = (
                    2.0
                    * pi
                    * (longitude_index + 1)
                    / self.longitude_part
                )

                self._add_vertex(vertex_data, latitude_0, longitude_0)
                self._add_vertex(vertex_data, latitude_1, longitude_0)
                self._add_vertex(vertex_data, latitude_1, longitude_1)

                self._add_vertex(vertex_data, latitude_0, longitude_0)
                self._add_vertex(vertex_data, latitude_1, longitude_1)
                self._add_vertex(vertex_data, latitude_0, longitude_1)

        return self.context.buffer(array("f", vertex_data).tobytes())

    def _calculate_vertex_count(self):
        return self.latitude_part * self.longitude_part * 6

    def _create_vertex_array(self, vertex_buffer):
        return self.context.vertex_array(
            self.shader.program,
            [(vertex_buffer, "3f 4f", "in_position", "in_color")],
        )

    def draw(self, camera, viewport_aspect):
        self.shader.apply_camera(camera, viewport_aspect)
        self.shader.apply_transform(self)
        self.vertex_array.render(
            mode=moderngl.TRIANGLES,
            vertices=self.vertex_count,
        )


from array import array
from math import pi, sqrt
from random import Random

import moderngl

# this classes makes the accretion disk functioninhg

class AccretionDisk(BaseObject):
    min_particle = 50000

    dark_orange = (0.36, 0.11, 0.02, 0.62)
    orange = (1.0, 0.38, 0.05, 0.72)
    yellow = (1.0, 0.78, 0.18, 0.82)
    white = (1.0, 0.96, 0.82, 0.92)

    def __init__(
        self,
        context,
        black_hole,
        inn_rad=Config.acc_disk_inn_rad,
        out_rad=Config.acc_disk_out_rad,
        thickness=Config.acc_disk_thickness,
        particle_count=Config.acc_disk_particles,
        randomness=Config.acc_disk_randomness,
        config=Config,
    ):
        super().__init__(position=black_hole.position)
        self.context = context
        self.black_hole = black_hole
        self.inn_rad = inn_rad
        self.out_rad = max(out_rad, inn_rad + 0.001)
        self.thickness = thickness
        self.radius_scale = config.acc_disk_default_scale
        self.particle_count = max(particle_count, self.min_particle)
        self.randomness = randomness
        self.gravitational_constant = (
            config.bh_gravitional_constant * black_hole.mass
        )
        self.gravitational_constant = max(self.gravitational_constant, 0.000001)
        self.orbit_time = 0.0

        self.context.enable(moderngl.PROGRAM_POINT_SIZE)
        self.shader_program = self._create_shader_program()
        self.quad_buffer = self.context.buffer(
            array(
                "f",
                [
                    -1.0,
                    -1.0,
                    1.0,
                    -1.0,
                    -1.0,
                    1.0,
                    1.0,
                    1.0,
                ],
            ).tobytes(),
        )
        self.instance_buffer = self.context.buffer(self._generate_particle_data())
        self.vertex_array = self._create_vertex_array()

    def _create_shader_program(self):
        return self.context.program(
            vertex_shader="""
                #version 330

                in vec2 in_corner;
                in float in_orbit_radius;
                in float in_orbit_phase;
                in float in_angular_velocity;
                in float in_height;
                in vec4 in_color;
                in float in_size;

                uniform mat4 view_matrix;
                uniform mat4 projection_matrix;
                uniform vec3 black_hole_position;
                uniform vec3 camera_right;
                uniform vec3 camera_up;
                uniform float orbit_time;
                uniform float disk_radius_scale;

                out vec4 particle_color;

                void main()
                {
                    float phase =
                        mod(
                            in_orbit_phase
                            + orbit_time * in_angular_velocity,
                            6.28318530718
                        );
                    vec3 orbit_position = vec3(
                        cos(phase) * in_orbit_radius * disk_radius_scale,
                        in_height * disk_radius_scale,
                        sin(phase) * in_orbit_radius * disk_radius_scale
                    );
                    vec3 particle_center = black_hole_position + orbit_position;
                    vec3 billboard_offset =
                        (camera_right * in_corner.x + camera_up * in_corner.y)
                        * in_size;

                    gl_Position =
                        projection_matrix
                        * view_matrix
                        * vec4(particle_center + billboard_offset, 1.0);
                    particle_color = in_color;
                }
            """,
            fragment_shader="""
                #version 330

                in vec4 particle_color;
                out vec4 fragment_color;

                void main()
                {
                    fragment_color = particle_color;
                }
            """,
        )

    def _create_vertex_array(self):
        return self.context.vertex_array(
            self.shader_program,
            [
                (self.quad_buffer, "2f", "in_corner"),
                (
                    self.instance_buffer,
                    "1f 1f 1f 1f 4f 1f /i",
                    "in_orbit_radius",
                    "in_orbit_phase",
                    "in_angular_velocity",
                    "in_height",
                    "in_color",
                    "in_size",
                ),
            ],
        )

    def _generate_particle_data(self):
        random_generator = Random(self.randomness)
        particle_data = []

        for _ in range(self.particle_count):
            orbit_radius = random_generator.uniform(
                self.inn_rad,
                self.out_rad,
            )
            orbit_phase = random_generator.uniform(0.0, 2.0 * pi)
            angular_velocity = self._angular_velocity(
                random_generator,
                orbit_radius,
            )
            radius_frac = self._radius_frac(orbit_radius)
            height = self._particle_height(random_generator, radius_frac)
            color = self._particle_color(random_generator, orbit_radius)
            size = random_generator.uniform(0.008, 0.022)
            particle_data.extend(
                [
                    orbit_radius,
                    orbit_phase,
                    angular_velocity,
                    height,
                    *color,
                    size,
                ]
            )

        return array("f", particle_data).tobytes()

    def _radius_frac(self, orbit_radius):
        return max(
            0.0,
            min(
                1.0,
                (orbit_radius - self.inn_rad)
                / (self.out_rad - self.inn_rad),
            ),
        )

    def _local_half_thickness(self, rad_frac):
        out_floor = 0.24
        inn_weight = (1.0 - rad_frac) ** 1.85
        return self.thickness * (out_floor + (1.0 - out_floor) * inn_weight)

    def _particle_height(self, random_generator, rad_frac):
        half_thickness = self._local_half_thickness(rad_frac)
        height = random_generator.gauss(0.0, half_thickness * 0.42)
        return max(-half_thickness, min(half_thickness, height))

    def set_radius_scale(self, radius_scale):
        self.radius_scale = radius_scale

    def _angular_velocity(self, random_generator, orbit_radius):
        stable_radius = max(orbit_radius, 0.000001)
        orbital_velocity = sqrt(self.gravitational_constant / stable_radius)
        angular_velocity = orbital_velocity / stable_radius
        speed_variation = random_generator.uniform(0.92, 1.08)
        return angular_velocity * speed_variation

    def _particle_color(self, random_generator, orbit_radius):
        radius_fraction = self._radius_frac(orbit_radius)
        heat = 1.0 - radius_fraction + random_generator.uniform(-0.08, 0.08)

        if heat > 0.82:
            return self.white
        if heat > 0.58:
            return self.yellow
        if heat > 0.28:
            return self.orange

        return self.dark_orange

    def update(self, delta_time):
        self.position = self.black_hole.position
        self.orbit_time += delta_time

    def draw(self, camera, viewport_aspect):
        self.shader_program["view_matrix"].write(camera.get_view_matrix().to_bytes())
        self.shader_program["projection_matrix"].write(
            camera.get_projection_matrix(viewport_aspect).to_bytes(),
        )
        self.shader_program["black_hole_position"].value = self.black_hole.position
        self.shader_program["camera_right"].value = (
            camera.right.x,
            camera.right.y,
            camera.right.z,
        )
        self.shader_program["camera_up"].value = (
            camera.up.x,
            camera.up.y,
            camera.up.z,
        )
        self.shader_program["orbit_time"].value = self.orbit_time
        self.shader_program["disk_radius_scale"].value = self.radius_scale
        self.vertex_array.render(
            mode=moderngl.TRIANGLE_STRIP,
            vertices=4,
            instances=self.particle_count,
        )


from array import array
from pathlib import Path

import moderngl

# this classs contains numerous rendering classes which helps in presenting (rendering) the objects.

class DynamicLineRenderer:

    def __init__(self, context, shader, ini_cap=4096):
        self.context = context
        self.shader = shader
        self.vertex_count = 0
        self.vertex_buffer = context.buffer(reserve=ini_cap)
        self.vertex_array = context.vertex_array(
            self.shader.program,
            [(self.vertex_buffer, "3f 4f", "in_position", "in_color")],
        )

    def update_vertices(self, vertices):
        self.vertex_count = len(vertices) // 7

        if self.vertex_count == 0:
            return

        vertex_bytes = array("f", vertices).tobytes()

        if len(vertex_bytes) > self.vertex_buffer.size:
            self.vertex_buffer.release()
            self.vertex_buffer = self.context.buffer(reserve=len(vertex_bytes))
            self.vertex_array = self.context.vertex_array(
                self.shader.program,
                [(self.vertex_buffer, "3f 4f", "in_position", "in_color")],
            )

        self.vertex_buffer.write(vertex_bytes)

    def render(self, camera, viewport_aspect):
        if self.vertex_count == 0:
            return

        self.shader.apply_camera(camera, viewport_aspect)
        self.vertex_array.render(mode=moderngl.LINES, vertices=self.vertex_count)


class BackgroundGrid:

    def __init__(self, context, shader, config=Config):
        self.line_renderer = DynamicLineRenderer(context, shader)
        self.base_size = config.grid_size
        self.grid_size = 20.0
        self.grid_colour = config.grid_color

    def _add_line(self, vertices, start_x, start_z, end_x, end_z, color):
        vertices.extend([start_x, 0.0, start_z, *color])
        vertices.extend([end_x, 0.0, end_z, *color])

    def update(self, world):
        sizing = self.base_size
        half_size = self.grid_size * 0.5
        line_count = int(self.grid_size / sizing) + 1
        vertices = []

        for index in range(line_count):
            coordinate = -half_size + index * sizing

            if abs(coordinate) < 0.0001:
                continue

            self._add_line(
                vertices,
                coordinate,
                -half_size,
                coordinate,
                half_size,
                self.grid_colour,
            )
            self._add_line(
                vertices,
                -half_size,
                coordinate,
                half_size,
                coordinate,
                self.grid_colour,
            )

        self.line_renderer.update_vertices(vertices)

    def render(self, camera, viewport_aspect):
        self.line_renderer.render(camera, viewport_aspect)


class CoordinateAxes:

    def __init__(self, context, shader, config=Config):
        self.line_renderer = DynamicLineRenderer(context, shader)
        self.x_axis_color = config.x_axis_color
        self.z_axis_color = config.z_axis_color

    def update(self, world):
        min_x, _, min_z = world.bounds_min
        max_x, _, max_z = world.bounds_max

        vertices = [
            min_x,
            0.0,
            0.0,
            *self.x_axis_color,
            max_x,
            0.0,
            0.0,
            *self.x_axis_color,
            0.0,
            0.0,
            min_z,
            *self.z_axis_color,
            0.0,
            0.0,
            max_z,
            *self.z_axis_color,
        ]

        self.line_renderer.update_vertices(vertices)

    def render(self, camera, viewport_aspect):
        self.line_renderer.render(camera, viewport_aspect)


class WorldBoundsRenderer:

    def __init__(self, context, shader, config=Config):
        self.line_renderer = DynamicLineRenderer(context, shader)
        self.bounds_color = config.bounds_color

    def update(self, world):
        min_x, _, min_z = world.bounds_min
        max_x, _, max_z = world.bounds_max
        color = self.bounds_color
        vertices = [
            min_x,
            0.0,
            min_z,
            *color,
            max_x,
            0.0,
            min_z,
            *color,
            max_x,
            0.0,
            min_z,
            *color,
            max_x,
            0.0,
            max_z,
            *color,
            max_x,
            0.0,
            max_z,
            *color,
            min_x,
            0.0,
            max_z,
            *color,
            min_x,
            0.0,
            max_z,
            *color,
            min_x,
            0.0,
            min_z,
            *color,
        ]
        self.line_renderer.update_vertices(vertices)

    def render(self, camera, viewport_aspect):
        self.line_renderer.render(camera, viewport_aspect)


class StarRenderer:

    def __init__(self, context, config=Config):
        self.context = context
        self.vertex_count = 0
        self.uploaded_star_ids = ()
        self.fade_start = max(config.size_of_world) * 0.45
        self.fade_end = max(config.size_of_world) * 1.5
        self.shader_program = self._create_shader_program()
        self.vertex_buffer = context.buffer(reserve=config.star_count * 9 * 4)
        self.vertex_array = context.vertex_array(
            self.shader_program,
            [
                (
                    self.vertex_buffer,
                    "3f 1f 1f 3f 1f",
                    "in_position",
                    "in_brightness",
                    "in_size",
                    "in_color",
                    "in_glow_strength",
                ),
            ],
        )

    def _create_shader_program(self):
        shader_directory = Path(__file__).with_name("shaders")
        return self.context.program(
            vertex_shader=self._load_shader_source(shader_directory, "star_billboard.vert"),
            geometry_shader=self._load_shader_source(shader_directory, "star_billboard.geom"),
            fragment_shader=self._load_shader_source(shader_directory, "star_billboard.frag"),
        )

    def _load_shader_source(self, shader_directory, file_name):
        return (shader_directory / file_name).read_text(encoding="utf-8")

    def update_stars(self, stars):
        star_ids = tuple(id(star) for star in stars)

        if star_ids == self.uploaded_star_ids:
            return

        vertex_data = []

        for star in stars:
            vertex_data.extend(
                [
                    star.position[0],
                    star.position[1],
                    star.position[2],
                    star.brightness,
                    star.size,
                    star.color[0],
                    star.color[1],
                    star.color[2],
                    star.glow_strength,
                ]
            )

        self.vertex_count = len(stars)

        if self.vertex_count == 0:
            self.uploaded_star_ids = star_ids
            return

        vertex_bytes = array("f", vertex_data).tobytes()

        if len(vertex_bytes) > self.vertex_buffer.size:
            self.vertex_buffer.release()
            self.vertex_buffer = self.context.buffer(reserve=len(vertex_bytes))
            self.vertex_array = self.context.vertex_array(
                self.shader_program,
                [
                    (
                        self.vertex_buffer,
                        "3f 1f 1f 3f 1f",
                        "in_position",
                        "in_brightness",
                        "in_size",
                        "in_color",
                        "in_glow_strength",
                    ),
                ],
            )

        self.vertex_buffer.write(vertex_bytes)
        self.uploaded_star_ids = star_ids

    def render(self, camera, viewport_aspect):
        if self.vertex_count == 0:
            return

        self.shader_program["view_matrix"].write(
            camera.get_view_matrix().to_bytes(),
        )
        self.shader_program["projection_matrix"].write(
            camera.get_projection_matrix(viewport_aspect).to_bytes(),
        )
        self.shader_program["camera_position"].value = camera.position_3d
        self.shader_program["camera_right"].value = (
            camera.right.x,
            camera.right.y,
            camera.right.z,
        )
        self.shader_program["camera_up"].value = (
            camera.up.x,
            camera.up.y,
            camera.up.z,
        )
        self.shader_program["fade_start"].value = self.fade_start
        self.shader_program["fade_end"].value = self.fade_end
        self.shader_program["viewport_height"].value = self._get_viewport_height()
        self.vertex_array.render(mode=moderngl.POINTS, vertices=self.vertex_count)

    def _get_viewport_height(self):
        viewport = getattr(self.context, "viewport", None)
        if viewport and len(viewport) == 4:
            return max(1.0, float(viewport[3]))

        return 720.0

# this class helps to render objects in correct order
class RenderManager:

    def __init__(self, context):
        self.star_renderer = StarRenderer(context)
        self.submitted_objects = []

    def begin_frame(self):
        self.submitted_objects.clear()

    def submit(self, base_object):
        self.submitted_objects.append(base_object)

    def render(self, camera, viewport_aspect):
        stars = [
            base_object
            for base_object in self.submitted_objects
            if isinstance(base_object, Star)
        ]
        black_holes = [
            game_object
            for game_object in self.submitted_objects
            if isinstance(game_object, BlackHole)
        ]
        accretion_disks = [
            game_object
            for game_object in self.submitted_objects
            if isinstance(game_object, AccretionDisk)
        ]
        
        self.star_renderer.update_stars(stars)
        self.star_renderer.render(camera, viewport_aspect)

        for accretion_disk in accretion_disks:
            accretion_disk.draw(camera, viewport_aspect)

        for black_hole in black_holes:
            black_hole.draw(camera, viewport_aspect)


from random import Random



class Scene:

    def __init__(self, context, shader, world, config=Config):
        self.world = world
        self.config = config
        self.render_manager = RenderManager(context)
        self.game_objects = []

        self._create_star_field()
        self.black_hole = BlackHole(
            context,
            shader,
            position=self.config.bh_position,
            mass=self.config.bh_mass,
            rotation=self.config.bh_rotation,
            radius=self.config.bh_radius,
            config=self.config,
        )
        self.game_objects.append(self.black_hole)
        self.accretion_disk = AccretionDisk(
            context,
            self.black_hole,
            inn_rad=self.config.acc_disk_inn_rad,
            out_rad=self.config.acc_disk_out_rad,
            thickness=self.config.acc_disk_thickness,
            particle_count=self.config.acc_disk_particles,
            randomness=self.config.acc_disk_randomness,
            config=self.config,
        )
        self.game_objects.append(self.accretion_disk)

    @property
    def black_hole_radius(self):
        return self.black_hole.radius

    @property
    def accretion_disk_scale(self):
        return self.accretion_disk.radius_scale

    @property
    def accretion_disk_outer_radius(self):
        return self.config.acc_disk_out_rad * self.accretion_disk.radius_scale

    def set_black_hole_radius(self, radius):
        radius = max(
            self.config.bh_min_radius,
            min(self.config.bh_max_radius, radius),
        )
        self.black_hole.set_radius(radius)

    def set_accretion_disk_scale(self, radius_scale):
        radius_scale = max(
            self.config.acc_disk_min_scale,
            min(self.config.acc_disk_max_scale, radius_scale),
        )
        self.accretion_disk.set_radius_scale(radius_scale)

    def set_accretion_disk_outer_radius(self, outer_radius):
        outer_radius = max(
            self.config.acc_disk_min_out_rad,
            min(self.config.acc_disk_max_out_rad, outer_radius),
        )
        radius_scale = outer_radius / self.config.acc_disk_out_rad
        self.set_accretion_disk_scale(radius_scale)

    def _create_star_field(self):
        random_generator = Random(self.config.star_randomness)
        min_x, min_y, min_z = self.world.bounds_min
        max_x, max_y, max_z = self.world.bounds_max

        for _ in range(self.world.star_count):
            position = (
                random_generator.uniform(min_x, max_x),
                random_generator.uniform(min_y, max_y),
                random_generator.uniform(min_z, max_z),
            )
            brightness, size, glow_strength = self._random_star_profile(
                random_generator,
            )
            color = self._random_temperature_color(random_generator)
            self.game_objects.append(
                Star(position, brightness, size, color, glow_strength),
            )

    def _random_star_profile(self, random_generator):
        category = random_generator.random()

        if category < 0.935:
            brightness = 0.08 + random_generator.random() ** 3.0 * 0.32
            size = random_generator.uniform(0.004, 0.012)
            glow_strength = 0.0
        elif category < 0.995:
            brightness = 0.36 + random_generator.random() ** 2.0 * 0.34
            size = random_generator.uniform(0.011, 0.024)
            glow_strength = random_generator.uniform(0.0, 0.18)
        else:
            brightness = 0.62 + random_generator.random() ** 2.0 * 0.28
            size = random_generator.uniform(0.022, 0.05)
            glow_strength = random_generator.uniform(0.2, 0.42)

        return brightness, size, glow_strength

    def _random_temperature_color(self, random_generator):
        temperature = random_generator.random()

        if temperature < 0.12:
            return (0.72, 0.43, 0.34)
        if temperature < 0.28:
            return (0.95, 0.62, 0.38)
        if temperature < 0.58:
            return (1.0, 0.86, 0.58)
        if temperature < 0.86:
            return (
                random_generator.uniform(0.9, 1.0),
                random_generator.uniform(0.92, 1.0),
                random_generator.uniform(0.88, 1.0),
            )

        return (
            random_generator.uniform(0.72, 0.84),
            random_generator.uniform(0.82, 0.94),
            1.0,
        )

    @property
    def game_object_count(self):
        return len(self.game_objects)

    @property
    def star_count(self):
        return sum(isinstance(game_object, Star) for game_object in self.game_objects)

    def update(self, delta_time):
        for game_object in self.game_objects:
            game_object.update(delta_time)

    def render(self, camera, viewport_aspect):
        self.render_manager.begin_frame()

        for game_object in self.game_objects:
            game_object.render(self.render_manager)

        self.render_manager.render(camera, viewport_aspect)


# this class stores the settings which are shared by thee scene

class World:

    def __init__(self, config=Config):
        self.size = config.size_of_world
        self.bounds_min = config.min_bounds
        self.bounds_max = config.max_bounds
        self.background_color = config.window_color
        self.grid_visible = config.grid_visible
        self.star_count = config.star_count



from array import array
from pathlib import Path
from math import tan

import glm
import moderngl


try:
    from PIL import Image
except ImportError:  # pragma: no cover - runtime fallback for lean installs.
    Image = None


class DeepSpaceBackground:

    def __init__(self, context, config=Config):
        self.context = context
        self.config = config
        self.quad_buffer = self.context.buffer(
            array(
                "f",
                [
                    -1.0,
                    -1.0,
                    1.0,
                    -1.0,
                    -1.0,
                    1.0,
                    1.0,
                    1.0,
                ],
            ).tobytes(),
        )
        self.shader_program = self._create_shader_program()
        self.quad_vertex_array = self.context.vertex_array(
            self.shader_program,
            [(self.quad_buffer, "2f", "in_position")],
        )
        self.panorama_texture = self._load_panorama_texture()

    def _create_shader_program(self):
        return self.context.program(
            vertex_shader="""
                #version 330

                in vec2 in_position;
                out vec2 screen_uv;

                void main()
                {
                    screen_uv = in_position * 0.5 + 0.5;
                    gl_Position = vec4(in_position, 0.0, 1.0);
                }
            """,
            fragment_shader="""
                #version 330

                uniform sampler2D panorama_texture;
                uniform vec3 camera_right;
                uniform vec3 camera_up;
                uniform vec3 camera_forward;
                uniform float tan_half_fov;
                uniform float aspect_ratio;
                uniform float background_intensity;
                uniform vec2 lens_center;
                uniform float lens_einstein_radius;
                uniform float lens_event_horizon_radius;
                uniform float lens_influence_radius;
                uniform float lens_softening;
                uniform float lens_ring_brightness;
                uniform float lens_visible;

                in vec2 screen_uv;
                out vec4 fragment_color;

                vec3 direction_from_plane(vec2 plane)
                {
                    return normalize(
                        camera_forward
                        + camera_right * plane.x
                        + camera_up * plane.y
                    );
                }

                vec2 screen_plane()
                {
                    vec2 ndc = screen_uv * 2.0 - 1.0;
                    return vec2(
                        ndc.x * aspect_ratio * tan_half_fov,
                        ndc.y * tan_half_fov
                    );
                }

                vec2 lensed_source_plane(vec2 image_plane, out float ring_strength)
                {
                    ring_strength = 0.0;

                    if (lens_visible < 0.5) {
                        return image_plane;
                    }

                    vec2 image_offset = image_plane - lens_center;
                    float image_radius = length(image_offset);
                    float safe_radius = max(image_radius, 0.00001);
                    vec2 radial_direction = image_offset / safe_radius;

                    // Thin-lens equation in angular camera-plane coordinates:
                    // beta = theta - theta_E^2 / theta. The panorama is sampled
                    // at beta, so only the infinitely distant background bends.
                    // Softening removes the singular center and prevents streaks.
                    float softened_radius_squared =
                        image_radius * image_radius
                        + lens_softening * lens_softening;
                    float bend =
                        lens_einstein_radius
                        * lens_einstein_radius
                        / softened_radius_squared;
                    vec2 source_plane =
                        lens_center + image_offset * (1.0 - bend);

                    float influence_fade = smoothstep(
                        lens_influence_radius * 0.82,
                        lens_influence_radius,
                        image_radius
                    );
                    float horizon_fade = smoothstep(
                        lens_event_horizon_radius * 0.22,
                        lens_event_horizon_radius * 0.92,
                        image_radius
                    );
                    source_plane = mix(
                        lens_center - radial_direction * lens_einstein_radius,
                        source_plane,
                        horizon_fade
                    );
                    source_plane = mix(source_plane, image_plane, influence_fade);

                    float ring_width = max(lens_einstein_radius * 0.075, 0.0025);
                    ring_strength =
                        exp(-pow((image_radius - lens_einstein_radius) / ring_width, 2.0))
                        * (1.0 - influence_fade)
                        * lens_visible;

                    return source_plane;
                }

                vec2 panorama_uv(vec3 direction)
                {
                    const float inverse_two_pi = 0.15915494309;
                    const float inverse_pi = 0.31830988618;
                    float u = atan(direction.z, direction.x) * inverse_two_pi + 0.5;

                    // The source image is stored top-to-bottom, so the north
                    // pole maps toward v=0 while preserving the panorama aspect.
                    float v = 0.5 - asin(clamp(direction.y, -1.0, 1.0)) * inverse_pi;
                    return vec2(fract(u), clamp(v, 0.001, 0.999));
                }

                void main()
                {
                    float ring_strength = 0.0;
                    vec2 image_plane = screen_plane();
                    vec2 source_plane = lensed_source_plane(image_plane, ring_strength);
                    vec3 direction = direction_from_plane(source_plane);
                    vec3 color = texture(panorama_texture, panorama_uv(direction)).rgb;

                    // A very small monochrome ring lift preserves the existing
                    // lensing cue without adding procedural stars or nebulae.
                    color += vec3(0.78, 0.82, 0.90)
                        * ring_strength
                        * lens_ring_brightness
                        * 0.10;
                    color *= background_intensity;

                    fragment_color = vec4(color, 1.0);
                }
            """,
        )

    def _load_panorama_texture(self):
        image_path = Path(__file__).with_name(self.config.galaxy_image)

        if Image is not None:
            with Image.open(image_path) as image:
                image = image.convert("RGB")
                texture = self.context.texture(image.size, 3, image.tobytes())
        else:
            texture = self._load_panorama_texture_with_pyglet(image_path)

        texture.repeat_x = True
        texture.repeat_y = False
        texture.filter = (
            moderngl.LINEAR_MIPMAP_LINEAR,
            moderngl.LINEAR,
        )
        texture.build_mipmaps()
        texture.use(location=0)
        return texture

    def _load_panorama_texture_with_pyglet(self, image_path):
        import pyglet

        image = pyglet.image.load(str(image_path))
        image_data = image.get_image_data()
        return self.context.texture(
            (image.width, image.height),
            3,
            image_data.get_data("RGB", image.width * 3),
        )

    def render(self, camera, viewport_aspect, black_hole=None):
        lensing = self._calculate_lensing_uniforms(camera, black_hole)
        self.context.depth_mask = False
        self.context.disable(moderngl.DEPTH_TEST)
        self.context.disable(moderngl.BLEND)

        try:
            self._render_panorama(camera, viewport_aspect, lensing)
        finally:
            self.context.enable(moderngl.BLEND)
            self.context.enable(moderngl.DEPTH_TEST)
            self.context.depth_mask = True

    def _calculate_lensing_uniforms(self, camera, black_hole):
        if black_hole is None:
            return {
                "center": (0.0, 0.0),
                "einstein_radius": 0.0,
                "event_horizon_radius": 0.0,
                "influence_radius": 0.0,
                "softening": 0.001,
                "visible": 0.0,
            }

        lens_position = glm.vec3(*black_hole.position)
        lens_vector = lens_position - camera.position
        forward_depth = glm.dot(lens_vector, camera.forward)

        if forward_depth <= camera.near_plane:
            return {
                "center": (0.0, 0.0),
                "einstein_radius": 0.0,
                "event_horizon_radius": 0.0,
                "influence_radius": 0.0,
                "softening": 0.001,
                "visible": 0.0,
            }

        event_horizon_radius = getattr(
            black_hole,
            "event_horizon_radius",
            getattr(black_hole, "radius", 0.75),
        )
        angular_event_horizon = event_horizon_radius / max(forward_depth, 0.0001)
        einstein_radius = angular_event_horizon * (
            1.0 + self.config.lens_power * 0.55
        )
        influence_radius = einstein_radius * self.config.lens_radius
        softening = max(
            angular_event_horizon * self.config.lens_softening,
            0.001,
        )

        return {
            "center": (
                glm.dot(lens_vector, camera.right) / forward_depth,
                glm.dot(lens_vector, camera.up) / forward_depth,
            ),
            "einstein_radius": einstein_radius,
            "event_horizon_radius": angular_event_horizon,
            "influence_radius": influence_radius,
            "softening": softening,
            "visible": 1.0,
        }

    def _render_panorama(self, camera, viewport_aspect, lensing):
        self.shader_program["camera_right"].value = (
            camera.right.x,
            camera.right.y,
            camera.right.z,
        )
        self.shader_program["camera_up"].value = (
            camera.up.x,
            camera.up.y,
            camera.up.z,
        )
        self.shader_program["lens_center"].value = lensing["center"]
        self.shader_program["lens_einstein_radius"].value = lensing["einstein_radius"]
        self.shader_program["lens_event_horizon_radius"].value = (
            lensing["event_horizon_radius"]
        )
        self.shader_program["camera_forward"].value = (
            camera.forward.x,
            camera.forward.y,
            camera.forward.z,
        
        )
        self.shader_program["tan_half_fov"].value = tan(camera.fov * 0.00872664626)
        self.shader_program["aspect_ratio"].value = viewport_aspect
        self.shader_program["background_intensity"].value = (
            self.config.galaxy_intensity
        )
        
        self.shader_program["lens_influence_radius"].value = lensing["influence_radius"]
        self.shader_program["lens_softening"].value = lensing["softening"]
        self.shader_program["lens_ring_brightness"].value = (
            self.config.lens_ring_brightness
        )
        self.shader_program["lens_visible"].value = lensing["visible"]
        self.panorama_texture.use(location=0)
        self.shader_program["panorama_texture"].value = 0
        self.quad_vertex_array.render(mode=moderngl.TRIANGLE_STRIP, vertices=4)

import pyglet


class SimulationSlider:

    def __init__(
        self,
        label,
        minimum,
        default,
        maximum,
        step,
        on_change,
        config,
    ):
        self.config = config
        self.label = label
        self.minimum = minimum
        self.maximum = maximum
        self.value = default
        self.step = step
        self.on_change = on_change
        self.x = 0
        self.y = 0
        self.width = config.debug_slider_width
        self.height = 22
        self.selected = False
        self.keyboard_direction = 0
        self.repeat_rate = config.debug_slider_key_repeat_rate
        self.value_label = pyglet.text.Label(
            "",
            font_name=config.debug_font,
            font_size=config.debug_font_size,
            anchor_x="left",
            anchor_y="bottom",
            color=config.debug_color,
            width=config.debug_slider_width,
        )
        self.selection_background = pyglet.shapes.Rectangle(
            0,
            0,
            self.width + 20,
            36,
            color=(44, 50, 62),
        )
        self.selection_background.opacity = 0
        self.track = pyglet.shapes.Rectangle(0, 0, self.width, 4, color=(72, 76, 86))
        self.fill = pyglet.shapes.Rectangle(0, 0, 1, 4, color=(205, 210, 220))
        self.knob = pyglet.shapes.Rectangle(0, 0, 9, 16, color=(245, 246, 250))

    def set_origin(self, x, y):
        self.x = x
        self.y = y
        self.value_label.x = self.x
        self.value_label.y = self.y + 18
        self.selection_background.x = self.x - 10
        self.selection_background.y = self.y - 10
        self.track.x = self.x
        self.track.y = self.y
        self.fill.x = self.x
        self.fill.y = self.y
        self.knob.y = self.y - 6

    def set_selected(self, selected):
        self.selected = selected
        if not selected:
            self.keyboard_direction = 0

    def start_keyboard_adjustment(self, direction):
        self.keyboard_direction = direction
        self.adjust(direction * self.step)

    def stop_keyboard_adjustment(self, direction):
        if self.keyboard_direction == direction:
            self.keyboard_direction = 0

    def update_keyboard(self, delta_time):
        if self.selected and self.keyboard_direction:
            self.adjust(self.keyboard_direction * self.repeat_rate * delta_time)

    def adjust(self, delta):
        self.value = max(self.minimum, min(self.maximum, self.value + delta))
        self.on_change(self.value)

    def sync_value(self, value):
        self.value = max(self.minimum, min(self.maximum, value))

    def draw(self):
        progress = self._progress()
        knob_x = self.x + progress * (self.width - self.knob.width)
        knob_center_x = knob_x + self.knob.width * 0.5
        self.value_label.text = f"{self.label}: {self.value:.2f}"
        self.value_label.color = (
            self.config.debug_selected_colour if self.selected else self.config.debug_color
        )
        self.selection_background.opacity = 145 if self.selected else 0
        self.fill.color = (238, 210, 132) if self.selected else (205, 210, 220)
        self.knob.color = (255, 238, 180) if self.selected else (245, 246, 250)
        self.fill.width = max(1, int(knob_center_x - self.x))
        self.knob.x = knob_x

        self.selection_background.draw()
        self.value_label.draw()
        self.track.draw()
        self.fill.draw()
        self.knob.draw()

    def _progress(self):
        return (self.value - self.minimum) / (self.maximum - self.minimum)


class DebugOverlay:

    def __init__(self, window_width, window_height, config=Config):
        self.config = config
        self.window_width = window_width
        self.window_height = window_height
        self.top_margin = config.debug_position[1]
        self.selected_slider_index = None
        self.label = pyglet.text.Label(
            "",
            font_name=config.debug_font,
            font_size=config.debug_font_size,
            x=config.debug_position[0],
            y=window_height - self.top_margin,
            anchor_x="left",
            anchor_y="top",
            multiline=True,
            width=config.debug_width,
            color=config.debug_color,
        )
        self.control_panel = pyglet.shapes.Rectangle(
            0,
            0,
            config.debug_panel_width,
            config.debug_panel_height,
            color=(18, 18, 24),
        )
        self.control_panel.opacity = 190
        self.sliders = [
            SimulationSlider(
                "Black Hole Size",
                config.bh_min_radius,
                config.bh_radius,
                config.bh_max_radius,
                config.bh_slider_step,
                lambda value: None,
                config,
            ),
            SimulationSlider(
                "Accretion Disk Size",
                config.acc_disk_min_out_rad,
                config.acc_disk_out_rad,
                config.acc_disk_max_out_rad,
                config.acc_disk_slider_step,
                lambda value: None,
                config,
            ),
        ]
        self._layout_sliders()

    def resize(self, window_width, window_height):
        self.window_width = window_width
        self.window_height = window_height
        self.label.y = window_height - self.top_margin
        self._layout_sliders()

    def bind_scene_controls(self, scene):
        self.sliders[0].on_change = scene.set_black_hole_radius
        self.sliders[1].on_change = scene.set_accretion_disk_outer_radius

    def update(self, fps, camera, scene, frame_time):
        self._update_selected_slider(frame_time)
        self.sliders[0].sync_value(scene.black_hole_radius)
        self.sliders[1].sync_value(scene.accretion_disk_outer_radius)
        frame_time_ms = frame_time * 1000.0
        self.label.text = (
            f"FPS: {fps:6.1f}\n"
            f"Frame Time: {frame_time_ms:6.2f} ms\n"
            f"BaseObjects: {scene.game_object_count}\n"
            f"Stars: {scene.star_count}\n"
            f"Camera X: {camera.position_x:7.3f}\n"
            f"Camera Y: {camera.position_y:7.3f}\n"
            f"Camera Z: {camera.position_z:7.3f}\n"
            f"Pitch: {camera.pitch:7.3f}\n"
            f"Yaw: {camera.yaw:7.3f}\n"
            f"FOV: {camera.fov:7.3f}"
        )

    def handle_key_event(self, key, action, keys):
        if action == keys.ACTION_PRESS:
            if self._key_matches(key, keys, self.config.bh_slider_key):
                self._select_slider(0)
                return True
            if self._key_matches(key, keys, self.config.acc_disk_key):
                self._select_slider(1)
                return True

        selected_slider = self._selected_slider()
        if selected_slider is None:
            return False

        if self._key_matches(key, keys, self.config.slider_decr_key):
            if action == keys.ACTION_PRESS:
                selected_slider.start_keyboard_adjustment(-1)
            elif action == keys.ACTION_RELEASE:
                selected_slider.stop_keyboard_adjustment(-1)
            return True

        if self._key_matches(key, keys, self.config.slider_inc_key):
            if action == keys.ACTION_PRESS:
                selected_slider.start_keyboard_adjustment(1)
            elif action == keys.ACTION_RELEASE:
                selected_slider.stop_keyboard_adjustment(1)
            return True

        return False

    def handle_mouse_press(self, x, y, button):
        return False

    def handle_mouse_drag(self, x, y):
        return False

    def handle_mouse_release(self):
        return False

    def owns_mouse(self, x, y):
        return False

    def draw(self):
        self.label.draw()
        self.control_panel.draw()

        for slider in self.sliders:
            slider.draw()

    def _layout_sliders(self):
        padding = self.config.debug_panel_padding
        panel_x = max(padding, self.window_width - self.config.debug_panel_width - padding)
        panel_y = padding
        slider_x = panel_x + self.config.debug_panel_inset
        slider_gap = self.config.debug_slider_vert_gap
        first_slider_y = panel_y + self.config.debug_panel_height - 48
        second_slider_y = first_slider_y - slider_gap

        self.control_panel.x = panel_x
        self.control_panel.y = panel_y

        self.sliders[0].set_origin(slider_x, first_slider_y)
        self.sliders[1].set_origin(slider_x, second_slider_y)

    def _select_slider(self, slider_index):
        self.selected_slider_index = slider_index
        for index, slider in enumerate(self.sliders):
            slider.set_selected(index == slider_index)

    def _selected_slider(self):
        if self.selected_slider_index is None:
            return None
        return self.sliders[self.selected_slider_index]

    def _update_selected_slider(self, delta_time):
        selected_slider = self._selected_slider()
        if selected_slider is not None:
            selected_slider.update_keyboard(delta_time)

    def _key_matches(self, key, keys, key_names):
        for key_name in key_names:
            key_value = getattr(keys, key_name, None)
            if key_value is not None and key == key_value:
                return True
        return False

import moderngl
import moderngl_window as mglw



class FpsCounter:

    def __init__(self):
        self.current_fps = 0.0
        self.elapsed_time = 0.0
        self.frame_count = 0

    def update(self, delta_time):
        self.elapsed_time += delta_time
        self.frame_count += 1

        if self.elapsed_time < 1.0:
            return False

        self.current_fps = self.frame_count / self.elapsed_time
        self.elapsed_time = 0.0
        self.frame_count = 0

        return True


class BlackHoleApplication(mglw.WindowConfig):

    RIGHT_MOUSE_BUTTON = 4

    gl_version = (3, 3)
    title = Config.window_name
    window_size = Config.size_of_window
    aspect_ratio = 16 / 9
    resizable = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.config = Config
        self.base_title = self.config.window_name
        self.world = World(self.config)
        self.ctx.enable(moderngl.BLEND)
        self.ctx.enable(moderngl.DEPTH_TEST)
        self.viewport_aspect = self.wnd.buffer_width / self.wnd.buffer_height
        self.delta_time = 0.0
        self.pressed_keys = set()
        self.right_mouse_down = False

        self.camera = Camera(self.config)
        self.fps_counter = FpsCounter()
        self.shape_shader = ColoredShapeShader(self.ctx)
        self.sky = DeepSpaceBackground(self.ctx, self.config)
        self.grid = BackgroundGrid(self.ctx, self.shape_shader, self.config)
        self.axes = CoordinateAxes(self.ctx, self.shape_shader, self.config)
        self.world_bounds = WorldBoundsRenderer(
            self.ctx,
            self.shape_shader,
            self.config,
        )
        self.scene = Scene(
            self.ctx,
            self.shape_shader,
            self.world,
            self.config,
        )
        self.debug_overlay = DebugOverlay(
            self.wnd.buffer_width,
            self.wnd.buffer_height,
            self.config,
        )
        self.debug_overlay.bind_scene_controls(self.scene)

    def _update_camera(self, delta_time):
        keys = self.wnd.keys
        forward = 0.0
        right = 0.0
        vertical = 0.0

        if keys.W in self.pressed_keys:
            forward += 1.0
        if keys.S in self.pressed_keys:
            forward -= 1.0
        if keys.D in self.pressed_keys:
            right += 1.0
        if keys.A in self.pressed_keys:
            right -= 1.0
        if keys.SPACE in self.pressed_keys:
            vertical += 1.0
        if keys.LEFT_CTRL in self.pressed_keys:
            vertical -= 1.0

        fast = self._is_key_pressed("LEFT_SHIFT") or self._is_key_pressed("RIGHT_SHIFT")
        self.camera.set_movement_input(forward, right, vertical, fast)

        self.camera.update(delta_time)
        self.camera.clamp_to_bounds(self.world)

    def _is_key_pressed(self, key_name):
        key = getattr(self.wnd.keys, key_name, None)
        return key in self.pressed_keys if key is not None else False

    def _update_fps(self, delta_time):
        if self.fps_counter.update(delta_time):
            fps = self.fps_counter.current_fps
            self.wnd.title = f"{self.base_title} - FPS: {fps:.0f}"

    def on_key_event(self, key, action, modifiers):
        keys = self.wnd.keys

        if self.debug_overlay.handle_key_event(key, action, keys):
            return

        if action == keys.ACTION_PRESS:
            self.pressed_keys.add(key)
            if key == keys.R:
                self.camera.reset()
        elif action == keys.ACTION_RELEASE:
            self.pressed_keys.discard(key)

    def on_resize(self, width, height):
        self.ctx.viewport = (0, 0, width, height)
        self.viewport_aspect = width / height if height else 1.0
        self.debug_overlay.resize(width, height)

    def on_mouse_position_event(self, x, y, dx, dy):
        if self.right_mouse_down:
            return

        if self.debug_overlay.owns_mouse(x, y):
            return

        self.camera.rotate(dx, dy)

    def on_mouse_press_event(self, x, y, button):
        if button == self.RIGHT_MOUSE_BUTTON:
            self.right_mouse_down = True
            return

        self.debug_overlay.handle_mouse_press(x, y, button)

    def on_mouse_release_event(self, x, y, button):
        if button == self.RIGHT_MOUSE_BUTTON:
            self.right_mouse_down = False
            return

        self.debug_overlay.handle_mouse_release()

    def on_iconify(self, iconify):
        if iconify:
            self.right_mouse_down = False
            self.debug_overlay.handle_mouse_release()

    def on_close(self):
        self.right_mouse_down = False
        self.debug_overlay.handle_mouse_release()

    def on_mouse_drag_event(self, x, y, dx, dy):
        if self.right_mouse_down:
            return

        if self.debug_overlay.handle_mouse_drag(x, y):
            return

        if self.debug_overlay.owns_mouse(x, y):
            return

        self.camera.rotate(dx, dy)

    def on_mouse_scroll_event(self, x_offset, y_offset):
        self.camera.adjust_move_speed(y_offset)

    def on_render(self, time, frame_time):
        self.delta_time = min(frame_time, 0.1)

        self._update_fps(self.delta_time)
        self._update_camera(self.delta_time)
        self.debug_overlay.update(
            self.fps_counter.current_fps,
            self.camera,
            self.scene,
            self.delta_time,
        )

        self.scene.update(self.delta_time)

        if self.world.grid_visible:
            self.grid.update(self.world)
        self.axes.update(self.world)
        self.world_bounds.update(self.world)

        self.ctx.clear(*self.world.background_color, depth=1.0)
        self.sky.render(self.camera, self.viewport_aspect, self.scene.black_hole)

        if self.world.grid_visible:
            self.grid.render(self.camera, self.viewport_aspect)

        self.world_bounds.render(self.camera, self.viewport_aspect)
        self.axes.render(self.camera, self.viewport_aspect)
        self.scene.render(self.camera, self.viewport_aspect)
        self.ctx.disable(moderngl.DEPTH_TEST)
        self.debug_overlay.draw()
        self.ctx.enable(moderngl.DEPTH_TEST)

import moderngl_window as mglw

if __name__ == "__main__":
    mglw.run_window_config(BlackHoleApplication)
